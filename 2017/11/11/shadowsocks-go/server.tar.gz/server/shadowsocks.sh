#!/bin/bash
./shadowsocks-server -c shadowsocks.json > log &.
