#!/bin/bash
./shadowsocks-local -c shadowsocks-local.json &.

